import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext'; // Ensure this path is correct
import Home from '@/pages/Home'; // Adjust paths as necessary
import { LoginForm } from '@/pages/Login';
import { SignUpForm } from '@/pages/Signup';
import ProductList from '@/pages/ProductList';
import ProductDetail from '@/pages/ProductDetail'; // Adjust path as necessary
import Dashboard from '@/admin/AdminDashboard';
import OrdersPage from '@/admin/OrdersPage';
import { Inventory } from './admin/InventoryPage';
import Customers from './admin/CustomerPage';
import Sales from '@/admin/SalesPage';
import TransactionsPage from '@/admin/TransactionsPage';
import Cart from '@/pages/Cart';
import CurrentOrdersPage from './admin/CurrentOrders';
import CompletedOrdersPage from './admin/CompletedOrders';


//need na matanggal dito yung mga dapat di naaaccess via changing the url
// customer ends are fine but for the admin side, need na log in lang ang accessible. It should also be imported path from each 

import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute: React.FC<{ allowedTypes: string[]; children: ReactNode }> = ({ allowedTypes, children }) => {
  const userType = localStorage.getItem('user_type');
  
  if (!userType || !allowedTypes.includes(userType)) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
};


const App = () => {
  return (
    <AuthProvider>
      <Router>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<LoginForm />} />
          
          {/* Protected Admin Route */}
          <Route 
            path="/admin-dashboard" 
            element={
              <ProtectedRoute allowedTypes={['admin']}>
                <Dashboard />
              </ProtectedRoute>
            } 
          />

          {/* Protected Customer Route */}
          <Route 
            path="/customer-dashboard" 
            element={
              <ProtectedRoute allowedTypes={['customer']}>
                <Customers />
              </ProtectedRoute>
            } 
          />


          <Route path="/" element={<Home />} /> {/* Home Page */}
          <Route path="/login" element={<LoginForm />} /> {/* Login Page */}
          <Route path="/signup" element={<SignUpForm />} /> {/* Sign Up Page */}
          <Route path="/products" element={<ProductList />} /> {/* Product List Page */}
          <Route path="/product/:id" element={<ProductDetail />} /> {/* Product Detail */}
          <Route path="/admin/dashboard" element={<Dashboard />}/>{/* Admin Dashboard */} 
          <Route path="/admin/orders" element={<OrdersPage />}/>{/* Orders */}
          <Route path="/admin/inventory" element={<Inventory />}/>{/* Inventory */}
          <Route path="/admin/customers" element={<Customers />}/>{/* Customers */}
          <Route path="/admin/sales" element={<Sales />}/>{/* Sales */}
          <Route path="/admin/transactions" element={<TransactionsPage />}/>{/* Transactions */}
          <Route path="/cart" element={<Cart />}/>{/* Cart */}
          <Route path="/admin/orders/current" element={<CurrentOrdersPage/>}/> {/* Current Orders*/}
          <Route path="/admin/orders/completed" element={<CompletedOrdersPage/>}/> {/* Completed Orders*/}

        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;
